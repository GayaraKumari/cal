package com.example.mobileiassistapp;

public class SaveGpa {
    private String title;
    private double gpa;

    public SaveGpa() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
}
