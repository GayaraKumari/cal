package com.example.mobileiassistapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MarkingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marking);
    }
}